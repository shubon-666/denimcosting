Denim Costing v24 - Old EJA Visual Preview
Created by Shubon

Deploy target/site name suggestion:
denimcostingshubon.netlify.app

Updates:
- Generate Costing preview now shows old Accounts EJA-style cost sheet look.
- Square Denims header/logo, green input cells, dotted borders, yarn specification table, cost details table, and signature lines.
- Excel export still uses/preserves the uploaded or built-in EJA template.
- App main name remains Denim Costing.
- Dark mode keeps preview readable as white Excel-style sheet.

Deploy:
Upload this folder or ZIP to Netlify.
